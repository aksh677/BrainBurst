var startTimer = document.getElementById("start-btn"); //Id of Start button
var startTimeField = document.getElementById("startTimeField");
if (startTimer) {
  startTimer.addEventListener("click", function () {
    startTimer = new Date();
    sessionStorage.setItem("startTimer", startTimer);
    console.log("starting time ", startTimer);
  });
}

var endTimer = document.getElementById("finish-btn"); //Id of Finish button
var endTimeField = document.getElementById("endTimeField");
if (endTimer) {
  endTimer.addEventListener("click", function () {
    endTimer = new Date();
    startTimeField.value = sessionStorage.getItem("startTimer");
    endTimeField.value = endTimer;
    console.log("ending time ", endTimer);
  });
}




// var startTimerButton = document.getElementById("start-btn"); //Id of Start button
// var startTimeField = document.getElementById("startTimeField");

// if (startTimerButton) {
//   startTimerButton.addEventListener("click", function () {
//     var startTime = new Date();
//     sessionStorage.setItem("startTimer", startTime);
//     startTimeField.value = startTime.toLocaleString(); // Display start time in a human-readable format
//     console.log("Starting time: ", startTime);
//   });
// }

// var endTimerButton = document.getElementById("finish-btn"); //Id of Finish button
// var endTimeField = document.getElementById("endTimeField");

// if (endTimerButton) {
//   endTimerButton.addEventListener("click", function () {
//     var endTime = new Date();
//     var startTime = new Date(sessionStorage.getItem("startTimer"));
//     endTimeField.value = endTime.toLocaleString(); // Display end time in a human-readable format
//     console.log("Ending time: ", endTime);
    
//     // Calculate and display elapsed time
//     var elapsedTime = (endTime - startTime) / 1000; // Convert milliseconds to seconds
//     console.log("Elapsed time: ", elapsedTime.toFixed(2), " seconds");
//   });
// }
